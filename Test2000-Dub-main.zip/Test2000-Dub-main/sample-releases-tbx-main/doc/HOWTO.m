%% HOWTO
%
% Using the |repository| function
%
%     repository
% 
% <<external.png>>
plot(randi(10, 10, 1)) 