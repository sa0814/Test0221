function repositoryMetadata = repository
    repositoryMetadata.name = "https://github.com/rks/sample-releases-tbx.git";
end

